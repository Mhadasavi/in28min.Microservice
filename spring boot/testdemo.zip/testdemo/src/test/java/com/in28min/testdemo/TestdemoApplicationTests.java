package com.in28min.testdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

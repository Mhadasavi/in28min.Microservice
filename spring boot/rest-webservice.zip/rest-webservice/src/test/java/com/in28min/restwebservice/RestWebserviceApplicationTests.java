package com.in28min.restwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}

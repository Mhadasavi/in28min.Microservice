package com.in28min.springboot.in28minspringbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class In28minSpringbootdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(In28minSpringbootdemoApplication.class, args);
	}

}

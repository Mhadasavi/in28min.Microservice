package com.in28min.springboot.in28minspringbootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class In28minSpringbootdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
